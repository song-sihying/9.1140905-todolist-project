from django.shortcuts import render, get_object_or_404
from .models import Todo
# Create your views here.


def view(request, id):
    todo = get_object_or_404(Todo, pk=id)
    date = todo.created.strftime('%Y-%m-%d %H:%M:%S')

    return render(request, './todo/view.html', {'todo': todo, 'date': date})


def todo(request):
    todos = None
    user = request.user
    if user.is_authenticated:
        todos = Todo.objects.filter(user=user)

    return render(request, './todo/todo.html', {'todos': todos})
