from django.shortcuts import redirect, render
from .forms import CustomUserForm
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate, logout
# Create your views here.


def user_logout(request):
    logout(request)

    return redirect('todo')


def profile(request):
    return render(request, './user/profile.html')


def user_login(request):
    message, username = '', ''
    if request.method == 'POST':
        if request.POST.get('register'):
            return redirect('register')

        if request.POST.get('login'):
            username = request.POST.get('username')
            password = request.POST.get('password')
            print(username, password)

            if username == '' or password == '':
                message = ' 帳號跟密碼不能為空!'
            else:
                user = authenticate(
                    request, username=username, password=password)

                if not user:
                    message = '帳號或密碼錯誤!'
                else:
                    message = '登入成功!'
                    login(request, user)

                    return redirect('todo')

    return render(request, './user/login.html', {'message': message, 'username': username})


def user_register(request):
    message = ''
    form = CustomUserForm()
    if request.method == 'POST':
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        email=request.POST.get('email')

        if password1 != password2:
            message = '兩次密碼不相同!'
        elif len(password1) < 8:
            message = '密碼過短'
        else:
            if User.objects.filter(username=username).exists():
                message = '帳號重複'
            else:
                user = User.objects.create_user(username=username, password=password1,email=email)
                user.save()
                login(request, user)
                message = '註冊成功!'

                return redirect('profile')

    return render(request, './user/register.html', {'form': form, 'message': message})
