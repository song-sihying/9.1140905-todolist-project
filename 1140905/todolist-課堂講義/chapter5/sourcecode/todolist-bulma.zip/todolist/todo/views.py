from django.shortcuts import render, get_object_or_404, redirect
from .models import Todo
from .forms import TodoForm
from datetime import datetime
from django.contrib.auth.decorators import login_required
# Create your views here.


@login_required
def completed_by_id(request, id):
    todo = Todo.objects.get(pk=id)

    todo.completed = not todo.completed
    todo.date_completed = datetime.now().strftime(
        '%Y-%m-%d %H:%M:%S') if todo.completed else None
    todo.save()

    return redirect('todo')


@login_required
def completed(request):
    todos = None
    user = request.user
    if user.is_authenticated:
        todos = Todo.objects.filter(user=user, date_completed__isnull=False)

    return render(request, './todo/completed.html', {'todos': todos})


@login_required
def create(request):
    form = TodoForm()

    if request.method == 'POST':
        form = TodoForm(request.POST)
        todo = form.save(commit=False)
        todo.user = request.user
        todo.save()

        return redirect('todo')

    return render(request, './todo/create.html', {"form": form,"date":datetime.now().strftime('%Y-%m-%d %H:%M:%S')})


def delete(request, id):
    todo = get_object_or_404(Todo, pk=id)
    todo.delete()

    return redirect('todo')


@login_required
def view(request, id):
    todo = get_object_or_404(Todo, pk=id)
    date = todo.created.strftime('%Y-%m-%d %H:%M:%S')
    form = TodoForm(instance=todo)

    if request.method == 'POST':
        if request.POST.get("update"):
            form = TodoForm(request.POST, instance=todo)
            if form.is_valid():
                todo = form.save(commit=False)
                todo.date_completed = datetime.now().strftime(
                    '%Y-%m-%d %H:%M:%S') if todo.completed else None
                todo.save()

        elif request.POST.get("delete"):
            todo.delete()

        return redirect('todo')

    return render(request, './todo/view.html', {'todo': todo, 'date': date, 'form': form})


def todo(request):
    todos = None
    user = request.user
    if user.is_authenticated:
        todos = Todo.objects.filter(user=user)

    return render(request, './todo/todo.html', {'todos': todos})
